/*
* @Author: Rosen
* @Date:   2018-01-31 13:06:57
* @Last Modified by:   Rosen
* @Last Modified time: 2018-02-04 22:21:43
*/
import React            from 'react';
import { BrowserRouter as Router, Switch, Redirect, Route, Link } from 'react-router-dom'

// 页面
import StockList      from 'page/stock/index/index.jsx';
import Send      from 'page/send/index/send.jsx';


class SendRouter extends React.Component{
    render(){
        return (
            <Switch>
                <Route path="/stock/index" component={StockList}/>
                <Redirect exact from="/stock" to="/stock/index"/>
                <Route path="/stock/send" component={Send}/>
            </Switch>
        )
    }
}
export default SendRouter;