/*
* @Author: Rosen
* @Date:   2018-02-01 16:19:36
* @Last Modified by:   Rosen
* @Last Modified time: 2018-02-04 21:39:59
*/
import React                from 'react';
import MUtil                from 'utils/mm.jsx'
import Product              from 'service/product-service.jsx'
import Alert from 'component/alert/index.jsx'
import User         from 'service/user-service.jsx'
//import SearchCom                from 'utils/searchCom.jsx'

// import PageTitle            from 'component/page-title/index.jsx';
// import FileUploader         from 'util/file-uploader/index.jsx'
// import RichEditor           from 'util/rich-editor/index.jsx'

// import './save.scss';

 const _mm           = new MUtil();
 const _product      = new Product();
 const _user      = new User();
import "./pop-send.scss"
class PopSend extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            // id                  : this.props.match.params.pid,
            id:"",
            name                : '',
            subtitle            : '',
            categoryId          : 0,
            parentCategoryId    : 0,
            subImages           : [],
            price               : '',
            stock               : '',
            detail              : '',
            status              : 1 ,//商品状态1为在售
            errMsg              :''
        }
    }
    // componentDidMount(){
    //     this.loadProduct();
    // }
    // 加载商品详情
    loadProduct(){
        // 有id的时候，表示是编辑功能，需要表单回填
        if(this.state.id){
            _product.getProduct(this.state.id).then((res) => {
                let images = res.subImages.split(',');
                res.subImages = images.map((imgUri) => {
                    return {
                        uri: imgUri,
                        url: res.imageHost + imgUri
                    }
                });
                res.defaultDetail = res.detail;
                this.setState(res);
            }, (errMsg) => {
                _mm.errorTips(errMsg);
            });
        }
    }
    onValueChange(e){
        let name = e.target.name,
            value = e.target.value.trim();
        this.setState({
            [name] : value
        });
    }
    // 品类选择器变化
    onCategoryChange(categoryId, parentCategoryId){
        this.setState({
            categoryId          : categoryId,
            parentCategoryId    : parentCategoryId
        });
    }
    // 上传图片成功
    onUploadSuccess(res){
        let subImages = this.state.subImages;
        subImages.push(res);
        this.setState({
            subImages : subImages
        });
    }
    // 上传图片失败
    onUploadError(errMsg){
        _mm.errorTips(errMsg);
    }
    // 删除图片
    onImageDelete(e){
        let index       = parseInt(e.target.getAttribute('index')),
            subImages   = this.state.subImages;
        subImages.splice(index, 1);
        this.setState({
            subImages : subImages
        });
    }
    // 富文本编辑器的变化
    onDetailValueChange(value){
        this.setState({
            detail: value
        });
    }
    getSubImagesString(){
        return this.state.subImages.map((image) => image.uri).join(',');
    }
    // clickFn(){
    //     console.log("点点")
    //     this.props.close()
    // }
    // 提交表单
    onSubmit(){

        let sendInfo = {
            name : this.state.name,
            subtitle : this.state.subtitle,
            id : ''
        };

        let checkResult = _product.checkSendInfo(sendInfo);
        // 验证通过
        if(checkResult.status){
            let selectInfo = {
                type: 'user_name',
                values: this.state.name
            };           
            _user.getUserInfo(selectInfo).then(res=>{
                if(res.status)
                    this.setState({
                    errMsg:'收货方不存在'
                    },()=>{
                        this.refs.alerterr.show()
                    });
                else{
                    sendInfo.id = res.data[0].user_id;
                    this.props.onSubmit(sendInfo);
                }
            });
        }
        // 验证不通过
        else{

             this.setState({
                errMsg:checkResult.msg
            },()=>{
             this.refs.alerterr.show()
            });
        }
        
    }
    render(){
        return (
            <div style={{"display":this.props.display}}>
            <div className="popcover"></div>
            <div className="popwrap">
            <div className="panel panel-primary" style={{maxWidth:'700px',width:'80%'}}>
                        <div className="panel-heading">
                            收货
                            <i className="glyphicon glyphicon-remove pull-right" onClick={this.props.close}></i>
                        </div>
                        <div className="panel-body">
                       
               
                <div className="form-horizontal">
                    <div className="form-group">
                        <label className="col-md-3 control-label">收货方名称</label>
                        <div className="col-md-9">
                            <input type="text" className="form-control" 
                                placeholder="请输入收货方名称"
                                name="name"
                                value={this.state.name}
                                onChange={(e) => this.onValueChange(e)}/>
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="col-md-3 control-label">运单号</label>
                        <div className="col-md-9">
                            <input type="text" className="form-control" 
                                placeholder="请输入运单号" 
                                name="subtitle"
                                value={this.state.subtitle}
                                onChange={(e) => this.onValueChange(e)}/>
                        </div>
                    </div>
                        
                    </div>
                
                        </div>
                    <div className="panel-footer">
                            <button type="submit" className="btn btn-primary center-block" 
                                onClick={(e) => {this.onSubmit(e)}}>提交</button>
                        </div>
                    </div>
                    </div>
                    <Alert title="提示" ref="alerterr" text={this.state.errMsg}  alertconfirm={(e)=>{}} alertclose={(e)=>{}} ></Alert>
                    </div>
        )
    }
}
export default PopSend;