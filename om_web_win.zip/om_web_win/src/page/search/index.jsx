/*
* @Author: Rosen
* @Date:   2018-01-31 20:54:10
* @Last Modified by:   Rosen
* @Last Modified time: 2018-01-31 21:46:52
*/
import React        from 'react';
import Product      from 'service/product-service.jsx'
import User         from 'service/user-service.jsx'
import MUtil        from 'utils/mm.jsx'
import { BrowserRouter as Router, Switch, Redirect, Route, Link } from 'react-router-dom'
import './index.scss';
import PageTitle    from 'component/page-title/index.jsx';
import Alert from 'component/alert/index.jsx'
import MobileHeader from 'component/mobileheader/index.jsx'

const _product      = new Product();
const _user         = new User();
const _mm           = new MUtil();
const style = {
    width: '500px' 
};

class Search extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            //searchType      : 'productId', //productId / productName
            searchKeyword   : '',
            search_result:''
        }
    }
    componentWillMount(){
            _user.login({username:'Admin@kehu.h3c.com',
                         password:'666666'
                             });
    }
    // 数据变化的时候
    onValueChange(e){
        let name    = e.target.name,
            value   = e.target.value.trim();
        this.setState({
            searchKeyword : value
        });
    }
    // 点击搜索按钮的时候
    onSearch(){
        let checkResult = _product.searchProduct(this.state.searchKeyword);
        if(checkResult.status){
            _product.search_secu(this.state.searchKeyword).then((res)=>{
                if(res.result!='{}'){
                    this.setState({
                       search_result:`您好，该条码为新华三信息技术有限公司的光模块条码，上一级发货单位是${JSON.parse(res.result).OWNER}，如与您获取的渠道不一致，请反馈`
                       },()=>{
                    this.refs.alerterr.show()
                    });
                    //alert(`您好，该条码为新华三技术有限公司的光模块条码，上一级发货单位是${JSON.parse(res.result).OWNER}，如与您获取的渠道不一致，请反馈`);
                }
                else
                    this.setState({
                       search_result:`您好，该条码不是新华三信息技术有限公司的光模块条码`
                       },()=>{
                    this.refs.alerterr.show()
                    });
                    //alert('您好，该条码不是新华三技术有限公司的光模块条码');


            },(errMsg)=>{

            });
        //this.props.history.push(`/product/detail/${this.state.searchKeyword}`);
       
         }
    }
    // 输入关键字后按回车，自动提交
    onSearchKeywordKeyUp(e){
        if(e.keyCode === 13){
            this.onSearch();
        }
    }

    alertclose(){}

    
    render(){
        return (
            
            <div id="page-wrapper">
            <MobileHeader title="防伪查询"></MobileHeader>
            <div className="row search-wrap-fake">
                <div className="col-md-offset-3 col-md-12">
                    <div className="form-inline">
                        <div className="form-group">
                            <input 
                                style={style}
                                type="text" 
                                className="form-control input-lg span3" 
                                placeholder="光模块ID"
                                name="searchKeyword"
                                onKeyUp={(e) => this.onSearchKeywordKeyUp(e)}
                                onChange={(e) => this.onValueChange(e)}/>
                        </div>
                        <button className="btn btn-primary btn-lg" 
                            onClick={(e) => this.onSearch()}>查询</button>
                    </div>
                </div>
            </div>
            <Alert title="查询结果" ref="alerterr" text={this.state.search_result} alert={this.alertshow} alertconfirm={(e)=>{this.alertclose()}} alertclose={(e)=>{this.alertclose()}}></Alert>
            </div>
        )
    }
    // 
    // render(){
    //     return(
    //         <div id="page-wrapper">
    //         <PageTitle title="溯源查询"/>
    //         <div className="row search-wrap-fake">
    //             <div className="col-md-offset-12 col-md-12 col-md-pull-2">
    //                 <ul className="nav nav-stacked step step-round vertical" data-step="1">
    //                     <li className="active">
    //                         <a>2019-4-5 : XXXXX收货</a>
    //                     </li>
    //                     <li className="active">
    //                         <a>我是进度二</a>
    //                     </li>
    //                     <li className="active">
    //                         <a>我是进度三</a>
    //                     </li>
    //                     <li className="active">
    //                         <a>我是进度四</a>
    //                     </li>
    //                     <li className="active">
    //                         <a>我是进度五</a>
    //                     </li>
    //                 </ul>
    //             </div>              
    //         </div>
    //     </div>
           

    //     )
    // }

 
}
export default Search;