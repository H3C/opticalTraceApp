/*
* @Author: Rosen
* @Date:   2018-01-31 13:06:57
* @Last Modified by:   Rosen
* @Last Modified time: 2018-02-04 22:21:43
*/
import React            from 'react';
import { BrowserRouter as Router, Switch, Redirect, Route, Link } from 'react-router-dom'

// 页面
import Trace      from 'page/trace/index/index.jsx';
import TraceDetail    from 'page/trace/index/detail.jsx';


class TraceRouter extends React.Component{
    render(){
        return (
            <Switch>
                <Route path="/trace/index" component={Trace}/>
                <Route path="/trace/detail/:pid" component={TraceDetail}/>
                <Redirect exact from="/trace" to="/trace/index"/>
            </Switch>
        )
    }
}
export default TraceRouter;