/*
* @Author: Rosen
* @Date:   2018-01-31 20:54:10
* @Last Modified by:   Rosen
* @Last Modified time: 2018-01-31 21:46:52
*/
import React        from 'react';
import Product      from 'service/product-service.jsx'
import MUtil        from 'utils/mm.jsx'
import { BrowserRouter as Router, Switch, Redirect, Route, Link } from 'react-router-dom'
import './index.scss';
import PageTitle    from 'component/page-title/index.jsx';
import MobileHeader from 'component/mobileheader/index.jsx'

const _product      = new Product();
const _mm           = new MUtil();
const style = {
    width: '500px' 
};

class Trace extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            //searchType      : 'productId', //productId / productName
            searchKeyword   : ''
        }
    }
    
    // 数据变化的时候
    onValueChange(e){
        let name    = e.target.name,
            value   = e.target.value.trim();
        this.setState({
            searchKeyword : value
        });
    }
    // 点击搜索按钮的时候
    onSearch(){
        let checkResult = _product.searchProduct(this.state.searchKeyword);
        if(checkResult.status){
        this.props.history.push(`/trace/detail/${this.state.searchKeyword}`);
        }
    }
    // 输入关键字后按回车，自动提交
    onSearchKeywordKeyUp(e){
        if(e.keyCode === 13){
            this.onSearch();
        }
    }
    render(){
        return (
            
            <div id="page-wrapper">
            <MobileHeader title="溯源查询"></MobileHeader>
            <div className="row search-wrap-fake">
                <div className="col-md-offset-3 col-md-12">
                    <div className="form-inline">
                        <div className="form-group">
                            <input 
                                style={style}
                                type="text" 
                                className="form-control input-lg span3" 
                                placeholder="光模块ID"
                                name="searchKeyword"
                                onKeyUp={(e) => this.onSearchKeywordKeyUp(e)}
                                onChange={(e) => this.onValueChange(e)}/>
                        </div>
                        <button className="btn btn-primary btn-lg" 
                            onClick={(e) => this.onSearch()}>查询</button>
                    </div>
                </div>
            </div>
            </div>
        )
    }
    // 
    // render(){
    //     return(
    //         <div id="page-wrapper">
    //         <PageTitle title="溯源查询"/>
    //         <div className="row search-wrap-fake">
    //             <div className="col-md-offset-12 col-md-12 col-md-pull-2">
    //                 <ul className="nav nav-stacked step step-round vertical" data-step="1">
    //                     <li className="active">
    //                         <a>2019-4-5 : XXXXX收货</a>
    //                     </li>
    //                     <li className="active">
    //                         <a>我是进度二</a>
    //                     </li>
    //                     <li className="active">
    //                         <a>我是进度三</a>
    //                     </li>
    //                     <li className="active">
    //                         <a>我是进度四</a>
    //                     </li>
    //                     <li className="active">
    //                         <a>我是进度五</a>
    //                     </li>
    //                 </ul>
    //             </div>              
    //         </div>
    //     </div>
           

    //     )
    // }

 
}
export default Trace;