/*
* @Author: Rosen
* @Date:   2018-01-31 20:54:10
* @Last Modified by:   Rosen
* @Last Modified time: 2018-01-31 21:46:52
*/
import React        from 'react';
import Product      from 'service/product-service.jsx'
import MUtil        from 'utils/mm.jsx'
import { BrowserRouter as Router, Switch, Redirect, Route, Link } from 'react-router-dom'
import './index.scss';
import PageTitle    from 'component/page-title/index.jsx';
import MobileHeader from 'component/mobileheader/index.jsx'
import Alert from 'component/alert/index.jsx'

const _product      = new Product();
const _mm           = new MUtil();
const style = {
    width: '500px' 
};

class TraceDetail extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            //searchType      : 'productId', //productId / productName
            searchKeyword   : '',
            id : this.props.match.params.pid,
            list:[]
        }
    }
    componentDidMount(){
        this.loadTraceList();
    }

    loadTraceList(){

        if(this.state.id){
            _product.getTraceList(this.state.id).then((res) => {
                if(res.success && res.result!='null'){
                    let list_origi = JSON.parse(res.result);
                    let list = [];
                    list_origi.map((product, index) => {
                        list.push({
                            date: product['value'].NODE_DATE,
                            owner: product['value'].OWNER,
                            status: product['value'].OptStatus,
                            shipment_id: product['value'].SHIPMENT_NUMBER
                        })
                    })
                    this.setState({
                        list: list
                    }
                    );

                }
                else{
                    this.refs.alerterr.show()
                }
            }, (errMsg) => {
                _mm.errorTips(errMsg);
            });
        }
    }

    // 数据变化的时候
    onValueChange(e){
        let name    = e.target.name,
            value   = e.target.value.trim();
        this.setState({
            searchKeyword : value
        });
    }
    // 点击搜索按钮的时候
    onSearch(){
        this.props.history.push(`/product/detail/${this.state.searchKeyword}`);
    }
    // 输入关键字后按回车，自动提交
    onSearchKeywordKeyUp(e){
        if(e.keyCode === 13){
            this.onSearch();
        }
    }
    alertclose(){
        this.props.history.push(`/trace`);
    }
    // render(){
    //     return (
            
    //         <div id="page-wrapper">
    //         <div className="row search-wrap-fake">
    //             <div className="col-md-offset-3 col-md-12">
    //                 <div className="form-inline">
    //                     <div className="form-group">
    //                         <input 
    //                             style={style}
    //                             type="text" 
    //                             className="form-control input-lg span3" 
    //                             placeholder="光模块ID"
    //                             name="searchKeyword"
    //                             onKeyUp={(e) => this.onSearchKeywordKeyUp(e)}
    //                             onChange={(e) => this.onValueChange(e)}/>
    //                     </div>
    //                     <button className="btn btn-primary btn-lg" 
    //                         onClick={(e) => this.onSearch()}>查询</button>
    //                 </div>
    //             </div>
    //         </div>
    //         </div>
    //     )
    // }
    // 
    render(){
        return(
            <div id="page-wrapper">
            <MobileHeader title="查询结果"></MobileHeader>
            <PageTitle title="溯源查询"/>
            <div className="row search-wrap-fake">
                <div className="col-md-offset-12 col-md-12 col-md-pull-2">
                    <ul className="nav nav-stacked step step-round vertical" data-step="1">
                    {
                        this.state.list.map((product, index) =>{
                            return(
                                <li className="active" key={index}>
                                     <a>{product.date}  :   {product.owner}   {(product.status=='1')?`发货   
                                      `:'收货'}  </a>
                                </li>
                            )
                        })
                    }
                    </ul>

                </div>              
            </div>
            <Alert title="提示" ref="alerterr" text='您好，该条码不是新华三技术有限公司的光模块条码' alert={this.alertshow} alertconfirm={(e)=>{this.alertclose()}} alertclose={(e)=>{this.alertclose()}}></Alert>
        </div>
           

        )
    }

 
}
export default TraceDetail;