/*
* @Author: Rosen
* @Date:   2018-01-31 13:06:57
* @Last Modified by:   Rosen
* @Last Modified time: 2018-02-04 22:21:43
*/
import React            from 'react';
import { BrowserRouter as Router, Switch, Redirect, Route, Link } from 'react-router-dom'

// 页面
import SendList      from 'page/send/index/index.jsx';
import Send      from 'page/send/index/send.jsx';


class SendRouter extends React.Component{
    render(){
        return (
            <Switch>
                <Route path="/send/index" component={SendList}/>
                <Redirect exact from="/send" to="/send/index"/>
                <Route path="/send/send" component={Send}/>
            </Switch>
        )
    }
}
export default SendRouter;