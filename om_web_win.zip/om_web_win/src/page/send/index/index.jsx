/*
* @Author: Rosen
* @Date:   2018-01-31 13:10:47
* @Last Modified by:   Rosen
* @Last Modified time: 2018-02-01 16:30:04
*/
import React        from 'react';
import { Link }     from 'react-router-dom';
import MUtil        from 'utils/mm.jsx'
import Product      from 'service/product-service.jsx'

import PageTitle    from 'component/page-title/index.jsx';
import ListSearch   from './index-list-search.jsx';
import TableList    from 'utils/table-list/index.jsx';
import Pagination   from 'utils/pagination/index.jsx';
import CheckboxItemcomponent    from 'utils/table-list/CheckboxItemcomponent.jsx';
import PopSend from './pop-send.jsx';
import MobileHeader from 'component/mobileheader/index.jsx'
import Alert from 'component/alert/index.jsx'

//import './index.scss';

const _mm           = new MUtil();
const _product      = new Product();

class SendList extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            list: [],
            pageNum         : 1,
            listType        : 'list',
            list_shelf      : [],
            chooseCheck : 0,
            Allchoose : false,
            reverseCheck : false,
            isAuto : false,
            searchType: 'productId',
            searchKeyword: '',
            popshow:false,
            display_name: 'none',
            confirmTips:'',
            resultTips:''

        };
    }
    componentDidMount(){
        //console.log(this.state.searchType);
        this.loadProductList();

    }

    // }
    loadProductList(){
        let listParam = {};
        listParam.pageNum  = this.state.pageNum;
        let searchType = this.state.searchType,
            searchKeyword = this.state.searchKeyword;
        let selectInfo={
            ownerId: JSON.parse(_mm.getStorage('userInfo')).user_number,
            receiveId:"",
            optstatus:2,
            transferPermissison: 1,
            barCode: searchType === 'productId'?searchKeyword:'' ,
            shipmentId: searchType === 'shipment_number'?searchKeyword:'',
            contractId: searchType === 'contract_id'?searchKeyword:'',

            pageNum:this.state.pageNum,
            pageSize:10
        }
        _product.getRecieveList(selectInfo).then(res => {
            // this.setState(res);
            // this.setState({
            //     list_shelf : []
            // });
        if(!res.status){
            let result = res.data;
            this.setState({
                total: result.total,
                list: result.list,
                chooseCheck : 0,
                Allchoose : false,
                reverseCheck : false,
                isAuto : false,
                list_shelf      : []
            });
    
       }
       else{
            this.setState({
                total: 0 ,
                list : [],
                list_shelf : [],
                chooseCheck : 0,
                Allchoose : false,
                reverseCheck : false,
                isAuto : false,
            });
            //_mm.errorTips(res.msg);
        }

        }, errMsg => {
            this.setState({
                list : [],
                list_shelf : []
            });
            _mm.errorTips(errMsg);
        });

    }
    // 搜索
    onSearch(searchType, searchKeyword){
        
            this.setState({
                pageNum         : 1,
                searchType      : searchType,
                searchKeyword   : searchKeyword,
            }, () => {
                //console.log(this.state.searchType+'---'+searchKeyword);
                this.loadProductList();
            });

        
    }
    // 页数发生变化的时候
    onPageNumChange(pageNum){
        this.setState({
            pageNum : pageNum
        }, () => {
            this.setState({
            list_shelf      : [],
            chooseCheck : 0,
            Allchoose : false,
            reverseCheck : false,
            isAuto : false
        })
            this.loadProductList();
        });
    }
    // 改变商品状态，上架 / 下架

    Allchoose(e){

        if(this.state.Allchoose){
            this.setState({
                chooseCheck : 0,
                Allchoose : false,
                isAuto : false,
                list_shelf      : [],
            })
        }else{
            const listIds = this.state.list.map(product=>product.id);
            this.setState({
                Allchoose : true,
                chooseCheck : this.state.list.length,
                isAuto : false,
                list_shelf      : listIds,
            });
        }
    }
    checkAllChoose(ItemChecked,productId){
        if(this.state.isAuto = true)this.state.isAuto = false;
        if(ItemChecked) 
        {
            this.state.chooseCheck++;
            this.state.list_shelf.push(productId);
        } 
        else
        {   this.state.chooseCheck--;
            this.state.list_shelf.splice(this.state.list_shelf.findIndex((value)=>(value==productId)), 1);
        }
        if(this.state.chooseCheck == this.state.list.length){
            this.setState({
                Allchoose : true,
                isAuto : true
            })
        }else{
            if(this.state.Allchoose == true){
                this.setState({
                    Allchoose : false,
                    isAuto : true
                });
            }
        }
    }
    Reversechoose(e){
        let newNum = this.state.list.length - this.state.chooseCheck;
        if(newNum == this.state.list.length){
            this.setState({
                Allchoose : true,
                isAuto : true
            })
        }else{
            this.setState({
                Allchoose : false,
                isAuto : true
            })
        }
        this.setState({
            reverseCheck : !this.state.reverseCheck,
            chooseCheck : this.state.list.length - this.state.chooseCheck
        });
    }
    showPop() { //编辑按钮的单击事件，修改状态机display_name的取值
        //let confrimTips =   `确定要发送下列${this.state.list_shelf.length}商品？${this.state.list_shelf}`;
        if(this.state.list_shelf.length>0){
             this.setState({
                 confirmTips:`确定要发送下列${this.state.list_shelf.length}件商品？`
             });
            this.refs.alertconfirm.show();
        } 
    }

    sendpop(){
        this.setState({
                display_name: 'block',
            })
    }

    controlshowalert(){
        this.refs.alertdanger.show()        
    }
     closePop(){    
        this.setState({display_name:'none'})
        this.loadProductList();

    }
    getTest(props){
        return 
        <button style="position:fixed;top:10px;left:50px">
         点击了弹窗
        </button>
      
    }

    // alertshow(ref){
    //     this.alertshow=ref
    // }
    showalert(){
        this.alertshow.show()
    }
    onSend(sendInfo){
        let user_number = JSON.parse(_mm.getStorage('userInfo')).user_number;
        let updateInfo={
            token:JSON.parse(_mm.getStorage('userInfo')).token,
            ids: this.state.list_shelf.join(","),
            receiveId: sendInfo.id,
            shipmentId: sendInfo.subtitle,
            contractId: ""
        };
        _product.send(updateInfo).then(res => {

            if(!res.status){
                this.setState({
                    resultTips:`操作成功`
                });
                let _this=this
                    setTimeout(function(){
                        _this.refs.alertdanger.show() 
                        _this.closePop()                
                    },) 
            }
            else{
                this.setState({
                    resultTips:res.msg
                });
                let _this=this
                    setTimeout(function(){
                        _this.refs.alertdanger.show();
                        _this.closePop();               
                    },) 
            }

        }, errMsg => {
            this.setState({
                list : [],
                list_shelf : []
            });
            _mm.errorTips(errMsg);
        });
             
    }

    alertclose(){
        //console.log('1');
        this.loadProductList();
    }



    
    render(){
        let tableHeads = [
            {name: '光模块ID', width: '40%'},
            {name: '运单号', width: '30%'},
            {name: '收货时间', width: '30%'},
            
        ];
        return (
            <div id="page-wrapper">
              <MobileHeader title="发货列表"></MobileHeader>
                <PageTitle title="发货列表">
                    <div className="page-header-right">
                        <button className="btn btn-lg btn-warning" 
                                onClick={(e) => {this.showPop()}}>发货</button>
                    </div>
                </PageTitle>
                <ListSearch total = {this.state.total} onSearch={(searchType, searchKeyword) => {this.onSearch(searchType, searchKeyword)}}/>
                <TableList checkbox="true" tableHeads={tableHeads} checked = {this.state.Allchoose} chooseAll = {(e)=>{this.Allchoose()}}>
                    {
                        this.state.list.map((product, index) => {
                            return (
                                <tr key={index}>
                                    <td><CheckboxItemcomponent value = {product.id} checkAllChoose = {(ItemChecked,productId)=>{this.checkAllChoose(ItemChecked,productId)}} Allchoose = {this.state.Allchoose} Reverse = {this.state.reverseCheck} isAuto = {this.state.isAuto}/></td>
                                    <td>{product.bar_code}</td>
                                    <td>{product.shipment_id}</td>
                                    <td>{product.node_date}</td>

                                </tr>
                            );
                        })
                    }
                </TableList>
                <ul  className="m-mobilelist visible-xs">
                    { this.state.list.map((product, index) => {
                            return (<li key={index} className="mobilelist-li">
                            <label htmlFor={product.id}>
                               <div className="col-xs-1"><CheckboxItemcomponent value = {product.id} checkAllChoose = {(ItemChecked,productId)=>{this.checkAllChoose(ItemChecked,productId)}} Allchoose = {this.state.Allchoose} Reverse = {this.state.reverseCheck} isAuto = {this.state.isAuto}/></div> 
                               <div className="col-xs-11">
                               
                                <p><span>光模块ID: </span><span>{product.bar_code}</span></p>
                                <p><span>运单号: </span><span>{product.shipment_id}</span></p>
                                <p><span className="pull-left">收货时间：{product.node_date}</span>
                                </p>
                                
                                </div>
                                </label>
                            </li>)}) }
                </ul>
                <Pagination current={this.state.pageNum} 
                    total={this.state.total} 
                    pageSize = {10}
                    onChange={(pageNum) => this.onPageNumChange(pageNum)}/>
                <div className="m-btmbtnw visible-xs">
                       <div className="btmbtnw-cont"> 
                             <button className="pull-left btn btn-lg btn-warning " onClick={(e) => {this.Allchoose()}}>
                                     全选</button> 

                             <button className="pull-right btn btn-lg btn-warning " onClick={(e) => {this.showPop()}}>
                                     发货</button>
                        </div>
                        <div className="btmbtnw-blank">

                        </div>
                </div> 
                <PopSend display={this.state.display_name} close={this.closePop.bind(this)} alertShow={this.controlshowalert.bind(this)} onSubmit={(sendInfo)=>this.onSend(sendInfo)}></PopSend>
                <Alert title="提示" ref="alertdanger" text={this.state.resultTips}  alert={this.alertshow} alertconfirm={(e)=>{this.alertclose()}}></Alert>
                <Alert title="操作确认" ref="alertconfirm" text={this.state.confirmTips} alert={this.alertshow} alertconfirm={(e)=>{this.sendpop(e)}} alertclose={e=>{this.alertclose()}}></Alert>
            </div>
        );
    }
}

export default SendList;