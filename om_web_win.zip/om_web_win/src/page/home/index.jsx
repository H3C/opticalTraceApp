/*
* @Author: Rosen
* @Date:   2018-01-23 18:03:55
* @Last Modified by:   Rosen
* @Last Modified time: 2018-01-26 13:41:51
*/

import React        from 'react';
import { Link }     from 'react-router-dom';

import MUtil        from 'utils/mm.jsx'
import Statistic    from 'service/statistic-service.jsx'

const _mm           = new MUtil();
const _statistic    = new Statistic();

import PageTitle    from 'component/page-title/index.jsx';
import searchImage  from  './home_files/search.svg';
import traceImage  from  './home_files/trace.svg';
import sendImage  from  './home_files/send.svg';
import receiveImage  from  './home_files/receive.svg';
import stockImage  from  './home_files/stock.svg';

const searchIcon = { backgroundSize:  '100% 100%', 
                     background:      `url(${ searchImage }) no-repeat center 0px`,
                     // width:200,
                     // height:200
 
                   },
      traceIcon = { backgroundSize:  '100% 100%', 
                     background:      `url(${ traceImage }) no-repeat center 0px`,
                     // width:200,
                     // height:200
 
                   },
      sendIcon = { backgroundSize:  '100% 100%', 
                     background:      `url(${ sendImage }) no-repeat center 0px`,
                     // width:200,
                     // height:200
 
                   },
      receiveIcon = { backgroundSize:  '100% 100%', 
                     background:      `url(${ receiveImage }) no-repeat center 0px`,
                     // width:200,
                     // height:200
 
                   },
      stockIcon = { backgroundSize:  '100% 100%', 
               background:      `url(${ stockImage }) no-repeat center 0px`,
               // width:200,
               // height:200

              };


import './index.scss'

class Home extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            userCount       : '-',
            productCount    : '-',
            orderCount      : '-'
        }
    }
    componentDidMount(){
        //this.loadCount();
        //window.location.href = "www.baidu.com";
    }
    loadCount(){
        _statistic.getHomeCount().then(res => {
            this.setState(res);
        }, errMsg => {
            _mm.errorTips(errMsg);
        });
    }
    // render(){
    //     return (
    //         <div id="page-wrapper">
    //             <PageTitle title="首页" />
    //             <div className="row">
    //                 <div className="col-md-4">
    //                     <Link to="/user" className="color-box brown">
    //                         <p className="count">{this.state.userCount}</p>
    //                         <p className="desc">
    //                             <i className="fa fa-user-o"></i>
    //                             <span>用户总数</span>
    //                         </p>
    //                     </Link>
    //                 </div>
    //                 <div className="col-md-4">
    //                     <Link to="/product" className="color-box green">
    //                         <p className="count">{this.state.productCount}</p>
    //                         <p className="desc">
    //                             <i className="fa fa-list"></i>
    //                             <span>商品总数</span>
    //                         </p>
    //                     </Link>
    //                 </div>
    //                 <div className="col-md-4">
    //                     <Link to="/order" className="color-box blue">
    //                         <p className="count">{this.state.orderCount}</p>
    //                         <p className="desc">
    //                             <i className="fa fa-check-square-o"></i>
    //                             <span>订单总数</span>
    //                         </p>
    //                     </Link>
    //                 </div>
    //             </div>
    //         </div>
    //     );
    // }
    render(){
        return (
          <div className="specialty">
  <div className="wrapper">
    <div className="support-title">
      <h1>H3C光模块溯源系统</h1>
    </div>
    <div className="support-body">
      <ul className="specialty-slide">

        <li>
          <a href="/search" className="list_home">
            <i style = {searchIcon}></i>
            <h1>防伪查询</h1>

          </a>
          <div className="specialty-content">
            <a href="/search">
              <h1>上云迁移服务</h1>
              <p>提供专业的迁移方案和专属迁移工具支持，保证客户云业务平滑迁移，缩短整体业务云化周期，解除客户顾虑，聚焦于业务发展。</p>
            </a>
          </div>
        </li>

        <li>
          <a href="/trace" className="list_home">
            <i style = {traceIcon}></i>
            <h1>溯源查询</h1>

          </a>
          <div className="specialty-content">
            <a href="/trace">
              <h1>云上保障护航服务</h1>
              <p>为您云上业务提供专属保障护航服务。遵循“事前重预防，事中重保障，事后重总结”原则，协助客户从容应对业务高峰。</p>
            </a>
          </div>
        </li>

        <li>
          <a href="/recieve" className="list_home">
            <i style = {receiveIcon}></i>
            <h1>我要收货</h1>
          </a>
          <div className="specialty-content">
            <a href="/recieve">
              <h1>可用性优化服务</h1>
              <p>基于您业务特点和对成本、性能和数据一致性的考虑，通过云服务资源来构建云上业务系统的可靠性，以免出现单点中断，降低故障几率，构建快速恢复能力。预防和面对突发问题，保障业务应用在复杂的环境下高效稳定运行。</p>
            </a>
          </div>
        </li>

        <li>
          <a href="/send" className="list_home">
            <i style = {sendIcon}></i>
            <h1>我要发货</h1>
          </a>
          <div className="specialty-content">
            <a href="/product">
              <h1>数据库咨询服务</h1>
              <p>华为云数据库专家团队为您数据库业务的上云迁移、系统容量规划、数据库架构设计与改造、系统性能调优等提供专业的在线咨询服务，数据库疑难杂症解决和数据库系统保驾护航服务。</p>
            </a>
          </div>
        </li>

        <li>
          <a href="/stock" className="list_home">
            <i style = {stockIcon}></i>
            <h1>我的库存</h1>
          </a>
          <div className="specialty-content">
            <a href="/product">
              <h1>数据库咨询服务</h1>
              <p>华为云数据库专家团队为您数据库业务的上云迁移、系统容量规划、数据库架构设计与改造、系统性能调优等提供专业的在线咨询服务，数据库疑难杂症解决和数据库系统保驾护航服务。</p>
            </a>
          </div>
        </li>

        

      </ul>
    </div>
  </div>
</div>
          );
    }
}

export default Home;