/*
* @Author: Rosen
* @Date:   2018-01-31 13:06:57
* @Last Modified by:   Rosen
* @Last Modified time: 2018-02-04 22:21:43
*/
import React            from 'react';
import { BrowserRouter as Router, Switch, Redirect, Route, Link } from 'react-router-dom'

// 页面
import RecieveList      from 'page/recieve/index/index.jsx';
import Recieve      from 'page/recieve/index/send.jsx';


class RecieveRouter extends React.Component{
    render(){
        return (
            <Switch>
                <Route path="/recieve/index" component={RecieveList}/>
                <Redirect exact from="/recieve" to="/recieve/index"/>
            </Switch>
        )
    }
}
export default RecieveRouter;