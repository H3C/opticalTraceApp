/*
* @Author: Rosen
* @Date:   2018-01-31 13:10:47
* @Last Modified by:   Rosen
* @Last Modified time: 2018-02-01 16:30:04
*/
import React        from 'react';
import { Link }     from 'react-router-dom';
import MUtil        from 'utils/mm.jsx'
import Product      from 'service/product-service.jsx'

import PageTitle    from 'component/page-title/index.jsx';
import ListSearch   from './index-list-search.jsx';
import TableList    from 'utils/table-list/index.jsx';
import Pagination   from 'utils/pagination/index.jsx';
import CheckboxItemcomponent    from 'utils/table-list/CheckboxItemcomponent.jsx';
import Alert        from 'component/alert/index.jsx'
import MobileHeader from 'component/mobileheader/index.jsx'
import './mobilelist.scss';

import './index.scss';

const _mm           = new MUtil();
const _product      = new Product();

class RecieveList extends React.Component{
    constructor(props){
        super(props);
        let confirm ='';
        this.state = {
            list: [],
            pageNum         : 1,
            listType        : 'list',
            list_shelf      : [],
            chooseCheck : 0,
            Allchoose : false,
            reverseCheck : false,
            isAuto : false,
            searchType: 'productId',
            searchKeyword: '',
            confirmTips:'',
            resultTips:'',
            isAll:false
        };
    }
    componentDidMount(){

        this.loadProductList();

    }

    // }
    loadProductList(){
        let listParam = {};
        // listParam.listType = this.state.listType;
        listParam.pageNum  = this.state.pageNum;
        let searchType = this.state.searchType,
            searchKeyword = this.state.searchKeyword;
        let selectInfo={
            ownerId: "",
            receiveId:JSON.parse(_mm.getStorage('userInfo')).user_number,
            optstatus:1,
            transferPermissison: "",
            barCode: searchType === 'productId'?searchKeyword:'' ,
            shipmentId: searchType === 'shipment_number'?searchKeyword:'',
            contractId: searchType === 'contract_id'?searchKeyword:'',

            pageNum:this.state.pageNum,
            pageSize:10
        }
        _product.getRecieveList(selectInfo).then(res => {
        if(!res.status){
            let result = res.data;
            this.setState({
                total: result.total,
                list: result.list,
                chooseCheck : 0,
                Allchoose : false,
                reverseCheck : false,
                isAuto : false,
                list_shelf      : []
            });
    
       }
       else{
            this.setState({
                total: 0 ,
                list : [],
                list_shelf : [],
                chooseCheck : 0,
                Allchoose : false,
                reverseCheck : false,
                isAuto : false,
            });
        }

        }, errMsg => {
            this.setState({
                list : [],
                list_shelf : []
            });
            _mm.errorTips(errMsg);
        });

    }
    // 搜索
    onSearch(searchType, searchKeyword){
        
            this.setState({
                pageNum         : 1,
                searchType      : searchType,
                searchKeyword   : searchKeyword,
            }, () => {
                //console.log(this.state.searchType+'---'+searchKeyword);
                this.loadProductList();
            });

        
    }
    // 页数发生变化的时候
    onPageNumChange(pageNum){
        this.setState({
            pageNum : pageNum
        }, () => {
            this.setState({
            list_shelf      : [],
            chooseCheck : 0,
            Allchoose : false,
            reverseCheck : false,
            isAuto : false
        })
            this.loadProductList();
        });
    }
    // 改变商品状态，上架 / 下架
    onReceipt(isAll){

        if(isAll){
            if(this.state.total>0){
                this.setState({
                   confirmTips:`确定要接收下列${this.state.total}件商品？`,
                   isAll: isAll
               });
                this.refs.alertconfirm.show()
            }
        }
        else{
            if(this.state.list_shelf.length>0){
                this.setState({
                    confirmTips:`确定要接收下列${this.state.list_shelf.length}件商品？`,
                    isAll: isAll
                });
                this.refs.alertconfirm.show()
            }
        }
    }
    alertclose(){
        this.loadProductList();
    }

    receipt(){
        let userInfo = JSON.parse(_mm.getStorage('userInfo')),
            receiptInfo = '';
        if(!this.state.isAll){
            receiptInfo={
                token:userInfo.token,
                ids: this.state.list_shelf.join(","),
                ownerId: userInfo.user_number
            };
            _product.receipt(receiptInfo).then(res => {

                if(!res.status){
                    this.setState({
                     resultTips:`操作成功`
                 });
                    let _this=this
                    setTimeout(function(){
                        _this.refs.alertdanger.show()              
                    },) 
                }
                else{
                    this.setState({
                       resultTips:res.msg
                   });
                    let _this=this
                    setTimeout(function(){
                        _this.refs.alertdanger.show()              
                    },2000) 
                }

            }, errMsg => {
                this.setState({
                    list : [],
                    list_shelf : []
                });
                _mm.errorTips(errMsg);
            });
        }
        else{
            let searchType = this.state.searchType,
                searchKeyword = this.state.searchKeyword;
            receiptInfo={
                token:JSON.parse(_mm.getStorage('userInfo')).token,
                ownerId: "",
                receiveId: userInfo.user_number,
                optstatus: 1,
                transferPermissison:"",
                barCode: searchType === 'productId'?searchKeyword:'' ,
                shipmentId: searchType === 'shipment_number'?searchKeyword:'',
                contractId: searchType === 'contract_id'?searchKeyword:'',
            };
            _product.receiptAll(receiptInfo).then(res => {

                if(!res.status){
                    this.setState({
                     resultTips:`操作成功`
                 });
                    let _this=this
                    setTimeout(function(){
                        _this.refs.alertdanger.show()              
                    },) 
                }
                else{
                    this.setState({
                       resultTips:res.msg
                   });
                    let _this=this
                    setTimeout(function(){
                        _this.refs.alertdanger.show()              
                    },) 
                }

            }, errMsg => {
                this.setState({
                    list : [],
                    list_shelf : []
                });
                _mm.errorTips(errMsg);
            });
        }
    }

    Allchoose(e){

        if(this.state.Allchoose){
            this.setState({
                chooseCheck : 0,
                Allchoose : false,
                isAuto : false,
                list_shelf      : [],
            })
        }else{
            const listIds = this.state.list.map(product=>product.id);
            this.setState({
                Allchoose : true,
                chooseCheck : this.state.list.length,
                isAuto : false,
                list_shelf      : listIds,
            });
        }
    }
    checkAllChoose(ItemChecked,productId){
        if(this.state.isAuto = true)this.state.isAuto = false;
        if(ItemChecked) 
            {
                this.state.chooseCheck++;
                this.state.list_shelf.push(productId);
            } 
        else
            {   this.state.chooseCheck--;
                this.state.list_shelf.splice(this.state.list_shelf.findIndex((value)=>(value==productId)), 1);
            }
 
        if(this.state.chooseCheck == this.state.list.length){
            this.setState({
                Allchoose : true,
                isAuto : true
            })
        }else{
            if(this.state.Allchoose == true){
                this.setState({
                    Allchoose : false,
                    isAuto : true
                });
            }
        }
    }
    Reversechoose(e){
        let newNum = this.state.list.length - this.state.chooseCheck;
        if(newNum == this.state.list.length){
            this.setState({
                Allchoose : true,
                isAuto : true
            })
        }else{
            this.setState({
                Allchoose : false,
                isAuto : true
            })
        }
        this.setState({
            reverseCheck : !this.state.reverseCheck,
            chooseCheck : this.state.list.length - this.state.chooseCheck
        });
    }

    // getAlertInfo(){
    //     return `确定要接收下列${this.state.list_shelf.length}商品？\n${this.state.list_shelf.join('\n')}`;
    // }



    
    render(){
        let tableHeads = [
            {name: '光模块ID', width: '30%'},
            {name: '运单号', width: '30%'},
            {name: '发货方', width: '20%'},
            {name: '发货时间', width: '20%'},
            
        ];
        return (
            <div id="page-wrapper" >
            <MobileHeader title="收货列表"></MobileHeader>

                <PageTitle title="收货列表">
                    <div className="page-header-right">
                        <button className="btn btn-lg btn-warning" 
                                onClick={(e) => {this.onReceipt()}}>收货</button>
                        <button className="btn btn-lg btn-warning button-all" onClick={(e) => {this.onReceipt(true)}}>
                                     批次收货</button>
                    </div>
                </PageTitle>
                <ListSearch total={this.state.total} onSearch={(searchType, searchKeyword) => {this.onSearch(searchType, searchKeyword)}}/>
                <TableList checkbox="true" tableHeads={tableHeads} checked = {this.state.Allchoose} chooseAll = {(e)=>{this.Allchoose()}}>
                    {
                        this.state.list.map((product, index) => {
                            return (
                                <tr key={index}>
                                    <td><CheckboxItemcomponent value = {product.id} checkAllChoose = {(ItemChecked,productId)=>{this.checkAllChoose(ItemChecked,productId)}} Allchoose = {this.state.Allchoose} Reverse = {this.state.reverseCheck} isAuto = {this.state.isAuto}/></td>
                                    <td>{product.bar_code}</td>
                                    <td>{product.shipment_id}</td>
                                    <td>{product.owner_name}</td>
                                    <td>{product.node_date}</td>

                                </tr>
                            );
                        })
                    }
                </TableList>
                <ul  className="m-mobilelist visible-xs">
                    { this.state.list.map((product, index) => {
                            return (<li key={index} className="mobilelist-li">
                            <label htmlFor={product.id}>
                               <div className="col-xs-1"><CheckboxItemcomponent value = {product.id} checkAllChoose = {(ItemChecked,productId)=>{this.checkAllChoose(ItemChecked,productId)}} Allchoose = {this.state.Allchoose} Reverse = {this.state.reverseCheck} isAuto = {this.state.isAuto}/></div> 
                               <div className="col-xs-11">
                               
                                <p><span>光模块ID:</span><span>{product.bar_code}</span></p>
                                <p><span>运单号:</span><span>{product.shipment_id}</span></p>
                                <p><span className="pull-right">{product.node_date}</span>
                                <span className="pull-left">发货方：{product.owner_name}</span></p>
                                
                                </div>
                                </label>
                            </li>)}) }
                </ul>
                <div className='pagination'>
                    <Pagination current={this.state.pageNum}
                    total={this.state.total} 
                    pageSize = {10}
                    onChange={(pageNum) => this.onPageNumChange(pageNum)}/>
                </div>
                <div className="m-btmbtnw visible-xs">
                       <div className="btmbtnw-cont"> 
                             <button className="pull-left btn btn-lg btn-warning " onClick={(e) => {this.Allchoose()}}>
                                     全选</button> 

                             <button className="pull-right btn btn-lg btn-warning " onClick={(e) => {this.onReceipt(false)}}>
                                     收货</button>
                             <button className="center-block btn btn-lg btn-warning " onClick={(e) => {this.onReceipt(true)}}>
                                     全部收货</button>
                        </div>
                        <div className="btmbtnw-blank">

                        </div>
                </div> 
            <Alert title="提示" ref="alertdanger" text={this.state.resultTips}  alert={this.alertshow} alertconfirm={(e)=>{this.alertclose()}} alertclose={(e)=>{this.alertclose()}}></Alert>
            <Alert title="操作确认" ref="alertconfirm" text={this.state.confirmTips} alert={this.alertshow} alertconfirm={(e)=>{this.receipt()}} alertclose={(e)=>{this.alertclose()}}></Alert>
            </div>
            
        );
    }
}

export default RecieveList;