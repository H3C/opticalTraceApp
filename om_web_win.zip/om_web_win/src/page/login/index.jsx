/*
* @Author: Rosen
* @Date:   2018-01-25 17:37:22
* @Last Modified by:   Rosen
* @Last Modified time: 2018-01-26 12:29:31
*/
import React        from 'react';
import MUtil        from 'utils/mm.jsx'
import User         from 'service/user-service.jsx'
import Alert from 'component/alert/index.jsx'

const _mm   = new MUtil();
const _user = new User();

import './index.scss';

class Login extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            username: '',
            password: '',
            redirect: _mm.getUrlParam('redirect') || '/',
            errMsg:''
        }
    }
    componentWillMount(){
        _mm.removeStorage('userInfo');

    }
    // 当用户名发生改变
    onInputChange(e){
        let inputValue  = e.target.value,
            inputName   = e.target.name;
        this.setState({
            [inputName] : inputValue
        });
    }
    onInputKeyUp(e){
        if(e.keyCode === 13){
            this.onSubmit();
        }
    }
    // 当用户提交表单
    onSubmit(){
        let loginInfo = {
                username : this.state.username.split('@')[0],
                password : this.state.password
            },
            checkResult = _user.checkLoginInfo(loginInfo);
        // 验证通过
        if(checkResult.status){
            _user.login(loginInfo).then((res) => {
                //由于cookie返回值异常，需登录两次
                if(res && res.access_token){
                    _mm.setCookie('token', res.access_token)
                }
                let token = res.access_token;
                let selectInfo = {
                    type: 'user_sso_correlation',
                    values: loginInfo.username
                };
                _mm.setCookie('isLogin','y');
                _user.getUserInfo(selectInfo).then((res)=>{
                    if(!res.status){
                        let user_info = res.data[0];
                        let data = {
                            user_name : user_info.user_name,
                            user_number   : user_info.user_id,
                            user_organ   : user_info.user_organ,
                            token: token
                            //egg_sess : egg_sess
                        };
                        _mm.setStorage('userInfo', data);
                        this.props.history.push(this.state.redirect);
                    }
                    else{
                        this.setState({
                             errMsg:'获取不到用户信息'
                        },()=>{
                          this.refs.alerterr.show()
                        });
                    }
                });
            }, (errMsg) => {
                this.setState({
                   errMsg:'账号或密码错误'
                },()=>{
                   this.refs.alerterr.show()
                });
            });
        }
        // 验证不通过
        else{
            this.setState({
                errMsg:checkResult.msg
            },()=>{
             this.refs.alerterr.show()
            });
        }
            
    }
    //


    render(){
        return (
            <div className="col-md-4 col-md-offset-4">
                <div className="panel panel-default login-panel">
                    <div className="panel-heading">欢迎登录 - H3C光模块溯源平台</div>
                    <div className="panel-body">
                        <div>
                            <div className="form-group">
                                    <input type="text"
                                    name="username"
                                    className="form-control"
                                    placeholder="请输入用户名" 
                                    onKeyUp={e => this.onInputKeyUp(e)}
                                    onChange={e => this.onInputChange(e)}/>
                            </div>
                            <div className="form-group">
                                <input type="password" 
                                    name="password"
                                    className="form-control" 
                                    placeholder="请输入密码" 
                                    onKeyUp={e => this.onInputKeyUp(e)}
                                    onChange={e => this.onInputChange(e)}/>
                            </div>
                            <button className="btn btn-lg btn-primary btn-block"
                                onClick={e => {this.onSubmit(e)}}>登录</button>
                        </div>
                    </div>
                </div>
                <Alert title="操作失败" ref="alerterr" text={this.state.errMsg} alert={this.alertshow} alertconfirm={(e)=>{}} alertclose={(e)=>{}} ></Alert>
            </div>

            
                    
        );
    }
}

export default Login;