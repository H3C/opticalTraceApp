/*
* @Author: Rosen
* @Date:   2018-01-31 13:19:15
* @Last Modified by:   Rosen
* @Last Modified time: 2018-02-04 22:52:34
*/
import MUtil        from 'utils/mm.jsx'

const _mm   = new MUtil();
//const _db           = require('utils/connect.js');
const config = JSON.parse(window.localStorage.getItem('config')) || {};
class Product{
    // 获取商品列表
    // getProductList(listParam){
    //     let url     = '',
    //         data    = {};
    //     if(listParam.listType === 'list'){
    //         url                         = '/manage/product/list.do';
    //         data.pageNum                = listParam.pageNum;
    //     }else if(listParam.listType === 'search'){
    //         url = '/manage/product/search.do';
    //         data.pageNum                = listParam.pageNum;
    //         data[listParam.searchType]  = listParam.keyword;
    //     }
    //     return _mm.request({
    //         type    : 'post',
    //         url     : url,
    //         data    : data
    //     });
    // }
    constructor(){
        this.channel_id = config.channelId || '5e688b54793a4c0056b50823' ;
        this.chaincode_id = config.chaincodeId || '5e688e26efd6330051227684' ;
    }
    test() {
        // _db.select(['user_name'], 'user', { user_name: 'yidai' }).then(result => {
        //     console.log(result[0].name);
        // });
        return 0;
    }
    getRecieveList(selectInfo){
        return _mm.request({
            type    : 'post',
            url     : '/om/list',
            data    : selectInfo
        });
    }
    getSendList(){
        let url     = `/v2/channels/${this.channel_id}/appOperation`,
            data    = {
                chaincode_operation: {
                operation: "query",
                functionName: "queryByinuse",
                args: JSON.parse(_mm.getStorage('userInfo')).user_number,
                chaincodeId: this.chaincode_id
                }
            };
        return _mm.request({
            type    : 'post',
            url     : url,
            data    : data
        });
    }
    // 获取商品详情
    getProduct(productId){
        return _mm.request({
            type    : 'post',
            url     : '/manage/product/detail.do',
            data    : {
                productId : productId || 0
            }
        });
    }
    // 变更商品销售状态
    setProductStatus(productInfo){
        return _mm.request({
            type    : 'post',
            url     : '/manage/product/set_sale_status.do',
            data    : productInfo
        });
    }
    // 检查保存商品的表单数据
    checkProduct(product){
        let result = {
            status: true,
            msg: '验证通过'
        };
        // 判断用户名为空
        if(typeof product.name !== 'string' || product.name.length ===0){
            return {
                status: false,
                msg: '商品名称不能为空！'
            }
        }
        // 判断描述不能为空
        if(typeof product.subtitle !== 'string' || product.subtitle.length ===0){
            return {
                status: false,
                msg: '商品描述不能为空！'
            }
        }
        // 验证品类ID
        if(typeof product.categoryId !== 'number' || !(product.categoryId > 0)){
            return {
                status: false,
                msg: '请选择商品品类！'
            }
        }
        // 判断商品价格为数字，且大于0
        if(typeof product.price !== 'number' || !(product.price >= 0)){
            return {
                status: false,
                msg: '请输入正确的商品价格！'
            }
        }
        // 判断库存为数字，且大于或等于0
        if(typeof product.stock !== 'number' || !(product.stock >= 0)){
            return {
                status: false,
                msg: '请输入正确的库存数量！'
            }
        }
        
        return result;
    }
    // 保存商品
    saveProduct(product){
        return _mm.request({
            type    : 'post',
            url     : '/manage/product/save.do',
            data    : product
        });
    }
    //test
    /*
    *  品类相关
    */
    // 根据父品类id获取品类列表
    getCategoryList(parentCategoryId){
        return _mm.request({
            type    : 'post',
            url     : '/manage/category/get_category.do',
            data    : {
                categoryId : parentCategoryId || 0
            }
        });
    }
    // 新增品类
    saveCategory(category){
        return _mm.request({
            type    : 'post',
            url     : '/manage/category/add_category.do',
            data    : category
        });
    }
    // 修改品类名称
    updateCategoryName(category){
        return _mm.request({
            type    : 'post',
            url     : '/manage/category/set_category_name.do',
            data    : category
        });
    }

    // 检查搜索条件
    searchProduct(searchValue){
        let value = $.trim(searchValue);
        // 判断用户名为空
        if(typeof value !== 'string' || value.length ===0){
            return {
                status: false,
                msg: '光模块ID不能为空！'
            }
        }
        return {
            status : true,
            msg : '验证通过'
        }
    }
    //防伪查询
    search_secu(keyword){
       return  _mm.request({
            type    : 'post',
            url     : `/v2/channels/${this.channel_id}/appOperation`,
            data    : {
                chaincode_operation: {
                operation: "query",
                functionName: "queryinfo",
                args: keyword,
                chaincodeId: this.chaincode_id
                }
            }
        })
    }
    //溯源查询
    getTraceList(keyword){
       return  _mm.request({
            type    : 'post',
            url     : `/v2/channels/${this.channel_id}/appOperation`,
            data    : {
                chaincode_operation: {
                operation: "query",
                functionName: "querytranstime",
                args: keyword,
                chaincodeId: this.chaincode_id
                }
            }
        })
    }
    //收货
    receipt(receiptInfo){
        return _mm.request({
            type    : 'post',
            url     : '/om/receive',
            data    : receiptInfo
        })
    }
    //全部收货
    receiptAll(receiptInfo){
        return _mm.request({
            type    : 'post',
            url     : '/om/receiveAll',
            data    : receiptInfo
        })
    }
    //发货
    send(sendInfo){
        return _mm.request({
            type    : 'post',
            url     : '/om/send',
            data    : sendInfo
        })
    }

    checkSendInfo(sendInfo){
        let name = $.trim(sendInfo.name),
            subtitle = $.trim(sendInfo.subtitle);

        // 判断用户名为空
        if(typeof name !== 'string' || name.length ===0){
            return {
                status: false,
                msg: '收货方不能为空！'
            }
        }
        return {
                    status : true,
                    msg : '验证通过'
                 }
    }
    
}

export default Product;
