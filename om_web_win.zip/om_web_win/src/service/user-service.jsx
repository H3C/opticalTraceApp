/*
* @Author: Rosen
* @Date:   2018-01-25 21:21:46
* @Last Modified by:   Rosen
* @Last Modified time: 2018-01-31 13:33:42
*/
import MUtil        from 'utils/mm.jsx'
//import DB        from 'utils/connect.jsx'

const _mm   = new MUtil();
//const _db   = new DB();

class User{
    constructor(){
	const config = JSON.parse(window.localStorage.getItem('config')) || {};
        this.clientId = config.clientId || 'GuangMoKuai';
        this.clientSecret = config.clientSecret || '666666';
    }
    // 用户登录
    login(loginInfo){
         const url  = `/oauth/token?client_id=${this.clientId}&client_secret=${this.clientSecret}&grant_type=password&scope=user_info&`+Object.keys(loginInfo).map(key => `${key}=${loginInfo[key]}`).join('&');
        return _mm.request({
            type: 'post',
            //url: '/manage/user/login.do',
            url: url,
            //url: '/user/login.do',
            data: loginInfo
        });
    }
    //用户名模糊匹配
    searchUser(keyword){
        return _mm.request({
            type: 'post',
            url: '/om/search-user',
            data: {
                userName: keyword
            }
        })
    }
    getUserInfo(selectInfo) {

        return _mm.request({
            type: 'post',
            url: '/om/getuserinfo',
            data: {
                type: selectInfo.type,
                values: selectInfo.values
            }
        });
    }

    getUsernameByOrgan(organ) {

        return _mm.request({
            type: 'post',
            url: `/v1/user/getinfo_organ`,
            data: {
                user_organ: organ
            }
        });
    }
    // 检查登录接口的数据是不是合法
    checkLoginInfo(loginInfo){
        let username = $.trim(loginInfo.username),
            password = $.trim(loginInfo.password);
        // 判断用户名为空
        if(typeof username !== 'string' || username.length ===0){
            return {
                status: false,
                msg: '用户名不能为空！'
            }
        }
        // 判断密码为空
        if(typeof password !== 'string' || password.length ===0){
            return {
                status: false,
                msg: '密码不能为空！'
            }
        }
        return {
            status : true,
            msg : '验证通过'
        }
    }
    // 退出登录
    logout(){
        return _mm.request({
            type    : 'post',
            url     : '/user/logout.do'
        });
    }
    getUserList(pageNum){
        return _mm.request({
            type    : 'post',
            url     : '/manage/user/list.do',
            data    : {
                pageNum : pageNum
            }
        });
    }
}

export default User;
