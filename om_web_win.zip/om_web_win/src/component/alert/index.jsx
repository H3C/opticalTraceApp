
import React        from 'react';
import "./alert.scss"
class Alert extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            cancel_display   : 'none',
            confirm_display   : 'block',
            show:this.props.show || false,
            isAll: false
        };
    }
    componentDidMount(){
        // this.props.onRef(this)
        
    }
    close(e){
        this.props.alertclose();
        this.setState({show:false});
    }
    show(){
        this.setState({
            show:true
        })
    }
    // show(isAll){
    //     this.setState({
    //         show:true,
    //         isAll: isAll
    //     })
    // }
    confirm(){
        this.props.alertconfirm();
        this.setState({show:false});
    }
    render(){
        return (
            <div style={{"display":this.state.show?'block':'none'}}>
            <div className="popcover"></div>
            <div className="popwrap">
            <div className="panel panel-primary" style={{maxWidth:'400px',width:'80%'}}>
                        <div className="panel-heading text-center">
                           {this.props.title}
                            <i className="glyphicon glyphicon-remove pull-right" onClick={this.close.bind(this)}></i>
                        </div>
                        <div className="panel-body text-center">                     
               
                        {this.props.text}
                
                        </div>
                    <div className="alert-footer">
                    <div className=" center-block" style={{display:'table'}}>
                    <button style={{"display":this.state.cancel_display}}  type="submit" className="btn btn-default mr10" 
                               >取消</button>
                            <button style={{"display":this.state.confirm_display}} type="submit" className="btn btn-primary" onClick={(e) => {this.confirm()}}
                               >确定</button></div>
                        </div>
                    </div>
                    </div></div>
        )}}
export default Alert