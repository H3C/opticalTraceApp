
import React            from 'react';
import "./mobileheader.scss"
class MobileHeader extends React.Component{
    render(){
        return (
            <div className="m-header hidden-sm hidden-md hidden-lg" >
            <div className="header-left"><a className="header-back" href='/'>返回</a> <div className="left-arrow"></div>
             </div> <h1 className="header-title"><span>{this.props.title}</span></h1> 
              <div className="vux-header-right"><a className="vux-header-more"></a>
               </div>
            </div>
           )
    }
}
export default MobileHeader