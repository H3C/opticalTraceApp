/*
* @Author: Rosen
* @Date:   2018-01-23 19:59:56
* @Last Modified by:   Rosen
* @Last Modified time: 2018-01-26 12:49:37
*/
import React        from 'react';
import { Link }     from 'react-router-dom';
import MUtil        from 'utils/mm.jsx'
import User         from 'service/user-service.jsx'

const _mm   = new MUtil();
const _user = new User();

class NavTop extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            user_name: _mm.includeCookie('isLogin')?(_mm.getStorage('userInfo')?JSON.parse(_mm.getStorage('userInfo')).user_name : ''):''

        }
    }
    onLogout(){
        _mm.removeStorage('userInfo');
        _mm.delCookie('isLogin');
         window.location.href = '/';
    }
    onLogin(){
       window.location.href = '/login'; 
    }
    render(){
        return (
            <div className="navbar navbar-default top-navbar">
                <div className='navbar-header hidden-xs'>
                      <a className='navbar-brand' href="/">首页</a>
                    
                </div>
                <ul className="nav navbar-top-links navbar-right">
                    <li className="dropdown">
                        <a className="dropdown-toggle" href="javascript:;">
                            <i className="fa fa-user fa-fw"></i>
                            {
                                this.state.user_name
                                ? <span>欢迎，{this.state.user_name}</span>
                                : <span>欢迎您</span>
                            }
                            <i className="fa fa-caret-down"></i>
                        </a>
                        <ul className="dropdown-menu dropdown-user">
                            <li>{
                                    this.state.user_name
                                    ?<a onClick={() => {this.onLogout()}}>
                                        <i className="fa fa-sign-out fa-fw"></i>
                                        <span>退出登录</span>
                                     </a>
                                    :<a onClick={() => {this.onLogin()}}>
                                        <i className="fa fa-sign-out fa-fw"></i>
                                        <span>登录</span>
                                     </a>
                                }
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        );
    }
}

export default NavTop;