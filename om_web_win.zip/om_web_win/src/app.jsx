/*
* @Author: Rosen
* @Date:   2018-01-13 11:27:21
* @Last Modified by:   Rosen
* @Last Modified time: 2018-02-05 14:02:20
*/  

import React            from 'react';
import ReactDOM         from 'react-dom';
import { BrowserRouter as Router, Switch, Redirect, Route, Link } from 'react-router-dom'

import Layout           from 'component/layout/index.jsx';
// 页面
import Home             from 'page/home/index.jsx';
import SendRouter       from 'page/send/router.jsx';
import TraceRouter       from 'page/trace/router.jsx';
import Login            from 'page/login/index.jsx';
import UserList         from 'page/user/index.jsx';
import ErrorPage        from 'page/error/index.jsx';
import Search           from 'page/search/index.jsx';
import PrivateRoute     from 'utils/privateRoute.jsx';
import RecieveRouter       from 'page/recieve/router.jsx';
import StockRouter       from 'page/stock/router.jsx';

import MUtil        from 'utils/mm.jsx'
import Statistic    from 'service/statistic-service.jsx'

const _mm           = new MUtil();
const _statistic    = new Statistic();
import axios        from 'axios';

// (() => {
//     if(window.localStorage.getItem('config')) {
// 	return;
//     } else {
// 	axios.get('/config/config.json').then(res => res && res.data && window.localStorage.setItem('config', JSON.stringify(res.data)))
//     }
// })()

class App extends React.Component{
    render(){
        let LayoutRouter = (
            <Layout> 
                <Switch>
                                   
                    <Route exact path="/" component={Home}/>
                    <Route path="/user/index" component={UserList}/>
                    <Route path="/search/index" component={Search}/>
                    <PrivateRoute path="/trace" component={TraceRouter}/>
                    <PrivateRoute path="/send" component={SendRouter}/>
                    <PrivateRoute path="/recieve" component={RecieveRouter}/>
                    <PrivateRoute path="/stock" component={StockRouter}/>
                    <Redirect exact from="/order" to="/order/index"/>
                    <Redirect exact from="/user" to="/user/index"/>
                    <Redirect exact from="/search" to="/search/index"/>
                   
                    
                    <Route component={ErrorPage}/>
                    <Route path="/" component={Login}/>
                
                </Switch>
            </Layout>
        );
        return (
            <Router>
                <Switch>
                    <Route path="/login" component={Login}/>
                    <Route path="/" render={ props => LayoutRouter}/>
                </Switch>
            </Router>
        )
    }
}


ReactDOM.render(
    <App />,
    document.getElementById('app')
);
