var express = require('express');   //引入express模块
var mysql = require('mysql');     //引入mysql模块
var app = express();

var _user = require('./user.jsx');
var BodyParser= require('body-parser');
app.use(BodyParser.urlencoded({ extended: true }));
app.all('*', function(req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");
        res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
        res.header("X-Powered-By",' 3.2.1')
        res.header("Content-Type", "application/json;charset=utf-8");
        next();
    });
// app.get('/v1/user/getinfo_organ/:organ',function (req,res) {
//      let info = {
//         organ: req.params.organ
//      }
//      _user. getUserByOrgan(info).then(result => {
        
//             res.status(200).json(result);
//         }).catch(err => {
          
//             res.status(500).json(err);

//         });
// });

//根据组织获取信息
app.post('/v1/user/getinfo_organ',function (req,res) {
    //console.log(req.body)
     let info = {
        user_organ: req.body.user_organ
     }
     _user. getUserByOrgan(info).then(result => {
        
            res.status(200).json(result);
        }).catch(err => {
          
            res.status(200).json(err);

        });
});
//根据用户名获取信息
app.post('/v1/user/getinfo_name',function (req,res) {
    //console.log(req.body)
     let info = {
        user_name: req.body.user_name
     }
     _user. getUserByName(info).then(result => {
        
            res.status(200).json(result);
        }).catch(err => {
          
            res.status(200).json(err);

        });
});

app.listen(8080,function () {    ////监听3000端口
});

