

const _db = require('./connectDao.jsx');
class User{
    getUserByOrgan(json) {
        return new Promise((resolve, reject) => {
           _db.select(['*'], 'user', { user_organ : json.user_organ}).then(result => {

                if (result.length > 0) {

                    resolve({success: true, result: result});
                } else {
 
                    reject({success: false, msg: '该组织不存在'});
                }
            });
        });
    }
    getUserByName(json) {
        return new Promise((resolve, reject) => {
            console.log(json.user_name);
           _db.select(['*'], 'user', { user_name : json.user_name}).then(result => {
                console.log(result);

                if (result.length > 0) {
                  
                    resolve({success: true, result: result});
                } else {
 
                    reject({success: false, msg: '该用户不存在'});
                }
            });
        });
    }




}
module.exports = new User();