import React,{Component} from 'react'
import ReactDOM,{render} from 'react-dom'
import User         from 'service/user-service.jsx'

const _user = new User();

class SearchCom extends Component{
    constructor(){
        super();
        this.state={
            val:"",
            arr:[],
            index:0,
            display:true
        }
    }
    handleChange(e){
        //this.setState({val:e.target.value});
        let keyword = e.target.value.trim();
        this.setState({
        	val:keyword,
        	arr:[]
        })
        if(keyword.length>0)
         _user.searchUser(e.target.value).then((res)=>{
        	if(res.list!=null){
        		this.setState({
        			arr:res.list,
        			display:true,
        			index:0
        		})
        	}
        	else
        		this.setState({
        			arr:[],
        		})
        })
        this.props.valueChange(this.state.val);
    }
    handleKeyUp(e){
    	let keyCode = e.keyCode;
    	if (keyCode === 38 || keyCode === 40){
    		new Promise((resolve,reject)=>{

    			if (keyCode === 38){
    				if (this.state.index<1){
    					this.setState({index:this.state.arr.length-1});
    				}
    				else{
    					this.setState({index:this.state.index-1})
    				}
    			}
    			else{
    				if (this.state.index>this.state.arr.length-2){
    					this.setState({index:0});
    				}
    				else{
    					this.setState({index:this.state.index+1})
    				}

    			}

    			resolve(this);
    		}).then(()=>{
    			if(this.state.index>=0){
    				this.setState({val:this.state.arr[this.state.index]})
    			}
    		})
    	}
    }
    handleKeyDown(e){
        if (e.keyCode ===13){
            this.refs.input.focus();
            this.setState({
        	display:false,
        	val:this.state.arr.length>0?this.state.arr[this.state.index]:this.state.val
        },(e)=>{
        	this.refs.input.value=this.state.val;
            this.props.valueChange(this.state.val);
        });
        }
    }
    componentDidMount(){
        //生命周期，在组件加载完成后，让input聚焦 (focus)
        this.refs.input.focus();
        this.props.valueChange(this.state.val);
    }
    handleMouseEnter(key,item,event){
        this.setState({index:key});
        //this.refs.input.value = item;
        this.props.valueChange(this.state.val);
    }

    handleClick(key,item,event){
        //window.open('https://www.baidu.com/s?wd=' + this.state.val, '_blank');
        this.refs.input.focus();
        this.setState({
        	display:false,
        	index:key,
        	val:item
        },()=>{
        	this.refs.input.value = item;
            this.props.valueChange(this.state.val);
        });
    }


    render(){
        let style ={marginTop:"20px"}
        return (
            <div className='container col-md-9'>
                <input className='form-control' type="text" ref='input' defaultValue={this.state.val} onChange={e=>this.handleChange(e)} onKeyUp={e=>this.handleKeyUp(e)} onKeyDown={e=>this.handleKeyDown(e)} className='form-control' placeholder='请输入收货方名称'/>
                { 
                   this.state.display?
                <ul className='list-group' >
                    {this.state.arr.map((item,key)=>{
                        return  <li onClick={event=>this.handleClick(key,item,event)} onMouseEnter={(event)=>this.handleMouseEnter(key,item,event)} className={key===this.state.index ? 'list-group-item active' :"list-group-item"} key={key}>{item}</li>
                    })}
                </ul>:''
                }

            </div>
        )
    }
}
export default SearchCom;