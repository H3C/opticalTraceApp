import React from 'react'
import { Route, Redirect } from 'react-router-dom'
import MUtil        from 'utils/mm.jsx'
import User         from 'service/user-service.jsx'
import Alert from 'component/alert/index.jsx'
const _mm   = new MUtil();
const _user = new User();
// 这个组件将根据登录的情况, 返回一个路由
const PrivateRoute = ({component: Component, props}) => {
    // 解构赋值 将 props 里面的 component 赋值给 Component
    return <Route {...props} render={(p) => {
        let username = _mm.getStorage('userInfo')?JSON.parse(_mm.getStorage('userInfo')).user_organ : '';
        if(window.location.pathname === '/search'){
        _user.login({username:'Admin@kehu.h3c.com',
                         password:'666666'
                        });
        }
        if (username&&_mm.includeCookie('isLogin')){ // 如果登录了, 返回正确的路由
            if(window.location.pathname === '/trace' && username != 'h3c'){

                return <Alert title="提示" ref="alerterr" text={'您没有溯源查询的权限'} alertconfirm={(e)=>{window.location.href = '/';}} alertclose={(e)=>{window.location.href = '/';}} show = 'true'></Alert>
            }
            else{
                return <Component />
            }
        } else { // 没有登录就重定向至登录页面


            return <Alert title="提示" ref="alerterr" text={'你还没有登录哦, 确认将跳转登录界面进行登录!'} alertconfirm={(e)=>{window.location.href = '/login?redirect=' + encodeURIComponent(window.location.pathname);}} alertclose={(e)=>{window.location.href = '/login?redirect=' + encodeURIComponent(window.location.pathname);}} show = 'true'></Alert>
        }
    }}/>
}
export default PrivateRoute;