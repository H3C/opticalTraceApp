/*
* @Author: Rosen
* @Date:   2018-01-31 13:25:05
* @Last Modified by:   Rosen
* @Last Modified time: 2018-01-31 20:52:46
*/
import React            from 'react';

// 通用的列表
class TableList extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            isFirstLoading: true
           
        };
    }
    componentWillReceiveProps(){
        // 列表只有在第一次挂载的时候，isFirstLoading为true，其他情况为false
        this.setState({
            isFirstLoading : false
        });
    }
    onChange(e){
        this.props.selectAll(e.target.checked);
    }
    //-------------------------------
    chooseAll(){
       this.props.chooseAll();
    }
   
    render(){
        // 表头信息
        let tableHeader = (
        //<th><input type="checkbox" onClick = {(e)=>{this.Allchoose(e)}} checked = {this.props.checked} /></th>
        //<th><input type = "checkbox" onChange={(e) => {this.onChange(e)}}/></th>
        this.props.tableHeads.map(
            (tableHead, index) => {
                if(typeof tableHead === 'object'){
                    return <th key={index} width={tableHead.width}>{tableHead.name}</th>
                }else if(typeof tableHead === 'string'){
                    return <th key={index}>{tableHead}</th>
                }
            }
        ));
        // 列表内容
        let listBody = this.props.children;
        // 列表的信息
        let listInfo = (
            <tr>
                <td colSpan={this.props.tableHeads.length+1} className="text-center">
                    {this.state.isFirstLoading ? '正在加载数据...' : '没有找到相应的结果~'}</td>
            </tr>
        );
        let tableBody = listBody.length > 0 ? listBody : listInfo;
        return (
            <div className="row hidden-xs">
                <div className="col-md-12">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                            {
                            this.props.checkbox?
                            <th> <input type="checkbox"  onClick = {(e)=>{this.chooseAll()}} checked = {this.props.checked} /></th>:<th style={{display:'none'}}></th>
                            }
                            {tableHeader}
                            </tr>
                        </thead>
                        <tbody>
                            {tableBody}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
}
export default TableList;
