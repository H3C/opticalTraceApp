import React            from 'react';

class CheckboxItemcomponent extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            checked : false,
        }
    }
    _clickHandle(e){
    	//console.log(this.props.value);
        this.props.checkAllChoose(!this.state.checked,this.props.value);
        this.setState({
            checked : this.state.checked ? false : true
        });
    }
    componentWillReceiveProps(nextprops){
        // console.log('1111',nextprops.isAuto);
        if(nextprops.isAuto == false)this.state.checked = nextprops.Allchoose;
        if(nextprops.Reverse != this.props.Reverse){
            this.setState({
                checked : !this.state.checked
            })
        }
    }
    render(){
        return (
            <input type="checkbox" value = {this.props.value} checked = {this.props.Allchoose ? this.props.Allchoose : this.state.checked} onClick = {(e)=>{this._clickHandle(e)}} />
        )
    }
}


export default CheckboxItemcomponent;